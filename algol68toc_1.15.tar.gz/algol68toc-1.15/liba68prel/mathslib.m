8
mod_info
ZTCAOSF
mathslib                        
                                
                                
0
                                
                                
0
-1
       
       
mathslib                        
0
0
0
1
105
070064001301001301047371727400640103657870006401026c6e00640103636f730064010373696e0064010374616e00640106617263636f730064010661726373696e0064010661726374616e0064010668616c6670690013010270690013010574776f70690013
AUCAOSF
1054329310
12
EUCAOSFtttftt#define EUCAOSF_sqrt sqrt
#include <math.h>

-----
FUCAOSFtttftt#define FUCAOSF_exp exp
#include <math.h>

-----
GUCAOSFtttftt#define GUCAOSF_ln log
#include <math.h>

-----
HUCAOSFtttftt#define HUCAOSF_cos cos
#include <math.h>

-----
IUCAOSFtttftt#define IUCAOSF_sin sin
#include <math.h>

-----
JUCAOSFtttftt#define JUCAOSF_tan tan
#include <math.h>

-----
KUCAOSFtttftt#define KUCAOSF_arccos acos
#include <math.h>

-----
LUCAOSFtttftt#define LUCAOSF_arcsin asin
#include <math.h>

-----
MUCAOSFtttftt#define MUCAOSF_arctan atan
#include <math.h>

-----
QUCAOSFftffff
RUCAOSFftffff
SUCAOSFftffff
