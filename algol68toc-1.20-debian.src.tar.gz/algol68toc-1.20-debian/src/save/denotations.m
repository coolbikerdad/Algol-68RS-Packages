8
mod_info
LLJACTR
denotations                     
                                
                                
0
                                
                                
0
-1
       
       
denotations                     
0
0
0
1
94
070064001a02041a000f0112636f6e766572747261646978737472696e670064070065001a01041a01137472616e736c61746564656e6f746174696f6e0065070066041a01041a01137265706c616365636f6e74726f6c63686172730066
MLJACTR
1618772872
3
GNJACTRfftfff
IOJACTRfftfff
DRJACTRfftfff
