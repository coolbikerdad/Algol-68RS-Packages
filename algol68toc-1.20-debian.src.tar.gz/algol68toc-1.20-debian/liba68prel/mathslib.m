8
mod_info
FTCAOSF
mathslib                        
                                
                                
0
                                
                                
0
-1
       
       
mathslib                        
0
0
0
1
105
070064001301001301047371727400640103657870006401026c6e00640103636f730064010373696e0064010374616e00640106617263636f730064010661726373696e0064010661726374616e0064010668616c6670690013010270690013010574776f70690013
GTCAOSF
1619019242
12
KTCAOSFtttftt#define KTCAOSF_sqrt sqrt
#include <math.h>

-----
LTCAOSFtttftt#define LTCAOSF_exp exp
#include <math.h>

-----
MTCAOSFtttftt#define MTCAOSF_ln log
#include <math.h>

-----
NTCAOSFtttftt#define NTCAOSF_cos cos
#include <math.h>

-----
OTCAOSFtttftt#define OTCAOSF_sin sin
#include <math.h>

-----
PTCAOSFtttftt#define PTCAOSF_tan tan
#include <math.h>

-----
QTCAOSFtttftt#define QTCAOSF_arccos acos
#include <math.h>

-----
RTCAOSFtttftt#define RTCAOSF_arcsin asin
#include <math.h>

-----
STCAOSFtttftt#define STCAOSF_arctan atan
#include <math.h>

-----
WTCAOSFftffff
XTCAOSFftffff
YTCAOSFftffff
