8
mod_info
YAAAASP
spaliens                        
                                
                                
0
                                
                                
0
-1
       
       
spaliens                        
0
0
0
1
1804
010b6665746f6e656172657374000f010a6665646f776e77617264000f070064000f01000f010a6665736574726f756e640064060065000f010a6665676574726f756e640065070066000f01001301056c72696e740066010c6e756c6c63636861727074720408010a6d617861627363686172000f01066d6178696e74000f010b73686f72746d6178696e740010011073686f727473686f72746d6178696e7400110108696e66696e6974790013010270690013011273686f72747265616c707265636973696f6e000f010e73686f72747265616c7769647468000f010e73686f7274736d616c6c7265616c0013010b73686f72746d696e657870000f010b73686f72746d6178657870000f010d7265616c707265636973696f6e000f01097265616c7769647468000f0109736d616c6c7265616c001301066d696e657870000f01066d6178657870000f01096572616e6765657272000f01076f72646f6e6c79000b01076f77726f6e6c79000b01056f72647772000b01066f6372656174000b01066f7472756e63000b01056f6578636c000b070067001301001301047371727400670103657870006701026c6e006701036c6f6700670103636f730067010373696e0067010374616e00670106617263636f730067010661726373696e0067010661726374616e0067010c7465726d696f737674696d65000f010b7465726d696f73766d696e000f0107746373616e6f77000b010469736967000b01066963616e6f6e000b01046563686f000b0106736967687570000f0106736967696e74000f010773696771756974000f0106736967696c6c000f010773696774726170000f010773696761627274000f0106736967627573000f0106736967667065000f01077369676b696c6c000f010773696775737231000f010773696773656776000f010773696775737232000f010773696770697065000f0107736967616c726d000f01077369677465726d000f010973696773746b666c74000f010773696763686c64000f0107736967636f6e74000f010773696773746f70000f010773696774737470000f01077369677474696e000f010773696774746f75000f0106736967757267000f010773696778637075000f01077369677866737a000f01097369677674616c726d000f010773696770726f66000f010873696777696e6368000f0105736967696f000f0106736967707772000f010c627974657370657262697473000f01056572726e6f040f01066166756e6978000f01066166696e6574000f010a736f636b73747265616d000f070068000f02001a000f010867635f706172616d00680600690005010f676172626167655f636f6c6c6563740069010d616c77617973636f6c6c656374000f010e616c7761797367726f7768656170000f010d64656661756c74706f6c696379000f0109616e73697261697365006407006a040b02000f040b010a616e73697369676e616c006a07006b001301001a010a616e7369737472746f64006b07006c000f03000f001a040f0109627364616363657074006c07006d000f03000f001a000f010762736462696e64006d010862736463686d6f640068010a627364636f6e6e656374006d07006e000f02000f000f01096273646663686d6f64006e07006f047001001a0a00700471f424000a00710008f424000110627364676574686f737462796e616d65006f070072000f02001a040b010b627364696e657461746f6e00720109627364697361747479006401096273646c697374656e006e070073000f01001a010a6273646d6b7374656d700073010b62736473687574646f776e006e070074000f03000f000f000f0109627364736f636b65740074070075000f05001a001a0013000f000f010f6273647265616c736e7072696e74660075070076000f01040b010969736f6174657869740076070077000f02040b0471010b6c696e75786f6e657869740077070078000f02000f0408010e6c696e75787463676574617474720078070079000f03000f000b0408010e6c696e75787463736574617474720079010c706f7369787365656b637572000f010c706f7369787365656b656e64000f010c706f7369787365656b736574000f07007a047101000f010d706f7369787374726572726f72007a010a706f736978636c6f73650064010a706f7369786372656174006807007b000501000f0109706f73697865786974007b07007c047101001a010b706f736978676574656e76007c010b706f7369786765747069640065010a706f7369786c7365656b007407007d000f03001a000f000f0109706f7369786f70656e007d0109706f73697872656164006d07007e000f02001a001a010b706f73697872656e616d65007e07007f000f010471010b706f7369787374726c656e007f070080000f01040f0109706f73697874696d650080010b706f736978756e6c696e6b0073010a706f7369787772697465006d
ZAAAASP
1618772901
122
VFAAASPttfftt#define VFAAASP_fetonearest FE_TONEAREST
#include <fenv.h>
#include <math.h>
#include <limits.h>

-----
WFAAASPttfftt#define WFAAASP_fedownward FE_DOWNWARD
/**/

-----
XFAAASPtttftt#define XFAAASP_fesetround fesetround
/**/

-----
YFAAASPfftfff
BGAAASPtttftt#define BGAAASP_lrint lrint
/**/

-----
BBAAASPttfftt#define BBAAASP_nullccharptr NULL
#include <stdio.h>

-----
CBAAASPttfftt#define CBAAASP_maxabschar A68_MAX_CHAR
/**/

-----
DBAAASPttfftt#define DBAAASP_maxint A68_MAX_INT
/**/

-----
EBAAASPttfftt#define EBAAASP_shortmaxint A68_MAX_SINT
/**/

-----
FBAAASPttfftt#define FBAAASP_shortshortmaxint A68_MAX_SSINT
/**/

-----
GBAAASPttfftt#define GBAAASP_infinity HUGE_VAL
#include <math.h>

-----
HBAAASPttfftt#define HBAAASP_pi M_PI
/**/

-----
IBAAASPttfftt#define IBAAASP_shortrealprecision FLT_MANT_DIG
#include <float.h>

-----
JBAAASPttfftt#define JBAAASP_shortrealwidth FLT_DIG
/**/

-----
KBAAASPttfftt#define KBAAASP_shortsmallreal FLT_EPSILON
/**/

-----
LBAAASPttfftt#define LBAAASP_shortminexp FLT_MIN_EXP
/**/

-----
MBAAASPttfftt#define MBAAASP_shortmaxexp FLT_MAX_EXP
/**/

-----
NBAAASPttfftt#define NBAAASP_realprecision DBL_MANT_DIG
/**/

-----
OBAAASPttfftt#define OBAAASP_realwidth DBL_DIG
/**/

-----
PBAAASPttfftt#define PBAAASP_smallreal DBL_EPSILON
/**/

-----
QBAAASPttfftt#define QBAAASP_minexp DBL_MIN_EXP
/**/

-----
RBAAASPttfftt#define RBAAASP_maxexp DBL_MAX_EXP
/**/

-----
XBAAASPttfftt#define XBAAASP_erangeerr ERANGE
#include <errno.h>

-----
YBAAASPttfftt#define YBAAASP_ordonly O_RDONLY
#include <fcntl.h>

-----
ZBAAASPttfftt#define ZBAAASP_owronly O_WRONLY
/**/

-----
ACAAASPttfftt#define ACAAASP_ordwr O_RDWR
/**/

-----
BCAAASPttfftt#define BCAAASP_ocreat O_CREAT
/**/

-----
CCAAASPttfftt#define CCAAASP_otrunc O_TRUNC
/**/

-----
DCAAASPttfftt#define DCAAASP_oexcl O_EXCL
/**/

-----
ECAAASPtttftt#define ECAAASP_sqrt sqrt
/**/

-----
FCAAASPtttftt#define FCAAASP_exp exp
/**/

-----
GCAAASPtttftt#define GCAAASP_ln log
/**/

-----
HCAAASPtttftt#define HCAAASP_log log10
/**/

-----
ICAAASPtttftt#define ICAAASP_cos cos
/**/

-----
JCAAASPtttftt#define JCAAASP_sin sin
/**/

-----
KCAAASPtttftt#define KCAAASP_tan tan
/**/

-----
LCAAASPtttftt#define LCAAASP_arccos acos
/**/

-----
MCAAASPtttftt#define MCAAASP_arcsin asin
/**/

-----
NCAAASPtttftt#define NCAAASP_arctan atan
/**/

-----
OCAAASPttfftt#define OCAAASP_termiosvtime VTIME
#include <termios.h>

-----
PCAAASPttfftt#define PCAAASP_termiosvmin VMIN
/**/

-----
QCAAASPttfftt#define QCAAASP_tcsanow TCSANOW
/**/

-----
RCAAASPttfftt#define RCAAASP_isig ISIG
/**/

-----
SCAAASPttfftt#define SCAAASP_icanon ICANON
/**/

-----
TCAAASPttfftt#define TCAAASP_echo ECHO
/**/

-----
XCAAASPttfftt#define XCAAASP_sighup SIGHUP
#include <signal.h>

-----
YCAAASPttfftt#define YCAAASP_sigint SIGINT
/**/

-----
ZCAAASPttfftt#define ZCAAASP_sigquit SIGQUIT
/**/

-----
ADAAASPttfftt#define ADAAASP_sigill SIGILL
/**/

-----
BDAAASPttfftt#define BDAAASP_sigtrap SIGTRAP
/**/

-----
CDAAASPttfftt#define CDAAASP_sigabrt SIGABRT
/**/

-----
DDAAASPttfftt#define DDAAASP_sigbus SIGBUS
/**/

-----
EDAAASPttfftt#define EDAAASP_sigfpe SIGFPE
/**/

-----
FDAAASPttfftt#define FDAAASP_sigkill SIGKILL
/**/

-----
GDAAASPttfftt#define GDAAASP_sigusr1 SIGUSR1
/**/

-----
HDAAASPttfftt#define HDAAASP_sigsegv SIGSEGV
/**/

-----
IDAAASPttfftt#define IDAAASP_sigusr2 SIGUSR2
/**/

-----
JDAAASPttfftt#define JDAAASP_sigpipe SIGPIPE
/**/

-----
KDAAASPttfftt#define KDAAASP_sigalrm SIGALRM
/**/

-----
LDAAASPttfftt#define LDAAASP_sigterm SIGTERM
/**/

-----
MDAAASPttfftt#define MDAAASP_sigstkflt SIGSTKFLT
/**/

-----
NDAAASPttfftt#define NDAAASP_sigchld SIGCHLD
/**/

-----
ODAAASPttfftt#define ODAAASP_sigcont SIGCONT
/**/

-----
PDAAASPttfftt#define PDAAASP_sigstop SIGSTOP
/**/

-----
QDAAASPttfftt#define QDAAASP_sigtstp SIGTSTP
/**/

-----
RDAAASPttfftt#define RDAAASP_sigttin SIGTTIN
/**/

-----
SDAAASPttfftt#define SDAAASP_sigttou SIGTTOU
/**/

-----
TDAAASPttfftt#define TDAAASP_sigurg SIGURG
/**/

-----
UDAAASPttfftt#define UDAAASP_sigxcpu SIGXCPU
/**/

-----
VDAAASPttfftt#define VDAAASP_sigxfsz SIGXFSZ
/**/

-----
WDAAASPttfftt#define WDAAASP_sigvtalrm SIGVTALRM
/**/

-----
XDAAASPttfftt#define XDAAASP_sigprof SIGPROF
/**/

-----
YDAAASPttfftt#define YDAAASP_sigwinch SIGWINCH
/**/

-----
ZDAAASPttfftt#define ZDAAASP_sigio SIGIO
/**/

-----
AEAAASPttfftt#define AEAAASP_sigpwr SIGPWR
/**/

-----
BEAAASPttfftt#define BEAAASP_bytesperbits BYTESPERBITS
#define BYTESPERBITS A_size_t_INT(sizeof(A68_INT))

-----
FEAAASPttfftt#define FEAAASP_errno errno
/**/

-----
CEAAASPttfftt#define CEAAASP_afunix AF_UNIX
#include <sys/socket.h>

-----
DEAAASPttfftt#define DEAAASP_afinet AF_INET
/**/

-----
EEAAASPttfftt#define EEAAASP_sockstream SOCK_STREAM
/**/

-----
GEAAASPtttftt#define GEAAASP_gc_param A_PARAM
#include <algol68/Alibrary.h>
#define A_PARAM(name,value) \
A_int_INT(Agc_param(A_VC_charptr(name),A_INT_int(value)))

-----
HEAAASPtttftt#define HEAAASP_garbage_collect Agc_collect
/**/

-----
IEAAASPttfftt#define IEAAASP_alwayscollect A_ALWAYS_COLLECT
#include <algol68/Alibrary.h>

-----
JEAAASPttfftt#define JEAAASP_alwaysgrowheap A_ALWAYS_GROW_HEAP
#include <algol68/Alibrary.h>

-----
KEAAASPttfftt#define KEAAASP_defaultpolicy A_DEFAULT_POLICY
#include <algol68/Alibrary.h>

-----
LEAAASPtttftt#define LEAAASP_ansiraise RAISE
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define RAISE(sig) raise(A_INT_int(A_INT_int(sig)))

-----
MEAAASPtttftt#define MEAAASP_ansisignal SIGNAL
#define SIGNAL(sig,handler) \
  (void *)signal(A_INT_int(sig),(void *)handler)

-----
NEAAASPtttftt#define NEAAASP_ansistrtod STRTOD
#define STRTOD(s) strtod(A_VC_charptr(s),NULL)

-----
OEAAASPtttftt#define OEAAASP_bsdaccept ACCEPT
#define ACCEPT(s,addr,addrlen) \
    A_int_INT(accept(A_INT_int(s),\
              (struct sockaddr *)A_VC_charptr(addr),(socklen_t *)addrlen))

-----
PEAAASPtttftt#define PEAAASP_bsdbind BIND
#define BIND(sockfd,addr,addrlen) \
   A_int_INT(bind(A_INT_int(sockfd),\
                  (struct sockaddr *)A_VC_charptr(addr),A_INT_int(addrlen)))

-----
QEAAASPtttftt#define QEAAASP_bsdchmod CHMOD
#define CHMOD(path,mode) \
   A_int_INT(chmod(A_VC_charptr(path),A_INT_int(mode)))

-----
REAAASPtttftt#define REAAASP_bsdconnect CONNECT
#define CONNECT(sockfd,servaddr,addrlen) \
   A_int_INT(connect(A_INT_int(sockfd),\
             (struct sockaddr *)A_VC_charptr(servaddr),A_INT_int(addrlen)))

-----
SEAAASPtttftt#define SEAAASP_bsdfchmod FCHMOD
#define FCHMOD(fd,mode) A_int_INT(fchmod(A_INT_int(fd),A_INT_int(mode)))

-----
TEAAASPtttftt#define TEAAASP_bsdgethostbyname GETHOSTBYNAME
#include <netdb.h>
#define GETHOSTBYNAME(host) (void *)gethostbyname(A_VC_charptr(host))

-----
UEAAASPtttftt#define UEAAASP_bsdinetaton INET_ATON
#define INET_ATON(cp,inp) \
   A_int_INT(inet_aton(A_VC_charptr(cp),(struct in_addr *)inp))

-----
VEAAASPtttftt#define VEAAASP_bsdisatty ISATTY
#define ISATTY(fd) A_int_INT(isatty(A_INT_int(fd)))

-----
WEAAASPtttftt#define WEAAASP_bsdlisten LISTEN
#define LISTEN(s,backlog) \
   A_int_INT(listen(A_INT_int(s),A_INT_int(backlog)))

-----
XEAAASPtttftt#define XEAAASP_bsdmkstemp MKSTEMP
#define MKSTEMP(id) A_int_INT(mkstemp(A_VC_charptr(id)))

-----
ZEAAASPtttftt#define ZEAAASP_bsdshutdown SHUTDOWN
#define SHUTDOWN(sd,direction) \
   A_int_INT(shutdown(A_INT_int(sd),A_INT_int(direction)))

-----
AFAAASPtttftt#define AFAAASP_bsdsocket SOCKET
#define SOCKET(domain,type,protocol) \
   A_int_INT(socket(A_INT_int(domain),\
                    A_INT_int(type),A_INT_int(protocol)))

-----
YEAAASPtttftt#define YEAAASP_bsdrealsnprintf REAL_SNPRINTF
#include <stdio.h>
#define REAL_SNPRINTF(buff,fmt,num,wd,prec) \
  A_int_INT(snprintf(A_VC_charptr(buff), \
                     A_INT_int(buff.upb), \
                     A_VC_charptr(fmt), \
                     (double)num,A_INT_int(wd), \
                                 A_INT_int(prec)))

-----
BFAAASPtttftt#define BFAAASP_isoatexit AT_EXIT
#define AT_EXIT(p) atexit((void *)p)

-----
CFAAASPtttftt#define CFAAASP_linuxonexit ON_EXIT
#define ON_EXIT(p,a) on_exit((void *)p,(void *)a)

-----
DFAAASPtttftt#define DFAAASP_linuxtcgetattr TCGETATTR
#define TCGETATTR(fd,t) \
    A_int_INT(tcgetattr(A_INT_int(fd), (struct termios*)t))

-----
EFAAASPtttftt#define EFAAASP_linuxtcsetattr TCSETATTR
#define TCSETATTR(fd,opt,t) \
    A_int_INT(tcsetattr(A_INT_int(fd), A_INT_int(opt),(struct termios*)t))

-----
VCAAASPttfftt#define VCAAASP_posixseekcur SEEK_CUR
/**/

-----
WCAAASPttfftt#define WCAAASP_posixseekend SEEK_END
/**/

-----
UCAAASPttfftt#define UCAAASP_posixseekset SEEK_SET
#include <sys/types.h>
#include <unistd.h>

-----
QFAAASPtttftt#define QFAAASP_posixstrerror STRERROR
#define STRERROR(e) (void *)strerror(e)

-----
FFAAASPtttftt#define FFAAASP_posixclose CLOSE
#define CLOSE(fd) A_int_INT(close(A_INT_int(fd)))

-----
GFAAASPtttftt#define GFAAASP_posixcreat CREAT
#define CREAT(path,mode) \
   A_int_INT(creat(A_VC_charptr(path),A_INT_int(mode)))

-----
HFAAASPtttftt#define HFAAASP_posixexit EXIT
#define EXIT(n) exit(n)

-----
IFAAASPtttftt#define IFAAASP_posixgetenv GETENV
#define GETENV(id) (void *)getenv(A_VC_charptr(id))

-----
JFAAASPfftfff
MFAAASPtttftt#define MFAAASP_posixlseek LSEEK
#define LSEEK(fd,offset,whence) \
   A_int_INT(lseek(A_INT_int(fd),A_INT_int(offset),A_INT_int(whence)))

-----
NFAAASPtttftt#define NFAAASP_posixopen OPEN
#define OPEN(path,flags,mode) \
   A_int_INT(open(A_VC_charptr(path),A_INT_int(flags),A_INT_int(mode)))

-----
OFAAASPtttftt#define OFAAASP_posixread READ
#define READ(fd,buf,count) \
   A_int_INT(read(A_INT_int(fd),A_VC_charptr(buf),A_INT_int(count)))

-----
PFAAASPtttftt#define PFAAASP_posixrename RENAME
#define RENAME(old,new) \
   A_int_INT(rename(A_VC_charptr(old),A_VC_charptr(new)))

-----
RFAAASPtttftt#define RFAAASP_posixstrlen STRLEN
#define STRLEN(s) strlen((char *)s)

-----
SFAAASPtttftt#define SFAAASP_posixtime TIME
#define TIME(t) A_time_t_INT(time(A_RI_time_tptr(t)))

-----
TFAAASPtttftt#define TFAAASP_posixunlink UNLINK
#define UNLINK(path) A_int_INT(unlink(A_VC_charptr(path)))

-----
UFAAASPtttftt#define UFAAASP_posixwrite WRITE
#define WRITE(fd,buf,count) \
   A_int_INT(write(A_INT_int(fd),A_VC_charptr(buf),A_INT_int(count)))

-----
