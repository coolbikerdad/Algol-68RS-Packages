8
mod_info
BAAACTR
incid                           
                                
                                
0
                                
                                
0
-1
       
       
incid                           
0
0
0
1
207
010a676c6f62616c69646e6f000f011b6b65707467656e657261746f7270726f63636f7272656374696f6e000f01076d617869646e6f000f01146d61786b65707467656e657261746f7270726f63000f01066d61786c6162000f01086d61786c69626964000f01096d61786f7069646e6f000f01076d617872646e6f000f01076d696e69646e6f000f01146d696e6b65707467656e657261746f7270726f63000f01066d696e6c6162000f01086d696e6c69626964000f01096d696e6f7069646e6f000f01076d696e72646e6f000f
CAAACTR
1619998576
14
GAAACTRttffff#define GAAACTR_globalidno 2
NAAACTRttffff#define NAAACTR_keptgeneratorproccorrection 6000
IAAACTRttffff#define IAAACTR_maxidno 2000
TAAACTRftffff
PAAACTRftffff
MAAACTRttffff#define MAAACTR_maxlibid 6000
RAAACTRttffff#define RAAACTR_maxopidno 65536
KAAACTRttffff#define KAAACTR_maxrdno 4000
HAAACTRttffff#define HAAACTR_minidno 3
SAAACTRftffff
OAAACTRttffff#define OAAACTR_minlab 16384
LAAACTRttffff#define LAAACTR_minlibid 4001
QAAACTRttffff#define QAAACTR_minopidno 32768
JAAACTRttffff#define JAAACTR_minrdno 2001
